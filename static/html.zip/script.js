

function rollCall() {
	var students = document.querySelectorAll('input[type="checkbox"]:checked');
	if (students.length > 0) {
		var randomIndex = Math.floor(Math.random() * students.length);
		var selectedStudent = students[randomIndex].value;
		document.getElementById('display').innerHTML = selectedStudent;
	} else {
		alert('Please select at least one student.');
	}
}